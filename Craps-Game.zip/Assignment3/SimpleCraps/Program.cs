﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Lakshay Punj
//April 17, 2019
//Craps Dice game

namespace SimpleCraps
{
    class Program
    {
        static void Main(string[] args)
        {

            //Declaring Variables for program and randomize numbers

            Random RanNum = new Random();
            string Roll;
            string PlayAgain;
            int DieSum;
         
            //Do Loop code to clear text upon restart
            do
            {

                Console.Clear();

                //Do loop for game's code
                do
                {
                    //Declaring two dice variables as random outputs
                    int Die1 = RanNum.Next(1, 6);
                    int Die2 = RanNum.Next(1, 6);
                    DieSum = Die1 + Die2;

                    //User inputs to roll dice
                    Console.WriteLine("Enter 1 to roll the dice");
                    Roll = Console.ReadLine();
           
                    //If/Else statement for game win, loss, try again outputs
                    if (DieSum == 7 || DieSum == 11)
                    {
                        Console.WriteLine("The dice rolls " + DieSum);
                        Console.WriteLine("You won the game! Congrats");
                    }

                    else if (DieSum == 2 || DieSum == 3 || DieSum == 12)
                    {
                        Console.WriteLine("The dice rolls " + DieSum);
                        Console.WriteLine("You lose the game");
                    }

                    else
                    {
                        Console.WriteLine("The dice rolls " + DieSum);
                        Console.WriteLine("Roll again!");
                    }
                    
                    //While code for program to run as long as required
                } while (DieSum != 7 && DieSum !=11 && DieSum != 2 && DieSum !=3 && DieSum !=12);

                //Asks user if they want to play again
                Console.WriteLine("Do you want to play again? Enter 1");
                PlayAgain = Console.ReadLine();

            //Concluding outputs, thanks for playing
            } while (PlayAgain == "1");
            Console.WriteLine("Thanks for playing!");

            Console.ReadKey();


        }
    }
}
